-- Create Tables

CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT,
    department_id INT
);

CREATE TABLE Departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(50)
);

CREATE TABLE Courses (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(50),
    department_id INT
);

CREATE TABLE Enrollments (
    enrollment_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    grade FLOAT
);

CREATE TABLE Professors (
    professor_id INT PRIMARY KEY,
    name VARCHAR(50),
    department_id INT
);

CREATE TABLE CourseAssignments (
    assignment_id INT PRIMARY KEY,
    course_id INT,
    professor_id INT,
    semester VARCHAR(20)
);

-- 🔹 Q1
SELECT S.name, C.course_name, E.grade
FROM Students S
LEFT JOIN Enrollments E ON S.student_id = E.student_id
LEFT JOIN Courses C ON E.course_id = C.course_id;

-- 🔹 Q2
SELECT D.department_name, COUNT(S.student_id) AS total_students
FROM Departments D
LEFT JOIN Students S ON D.department_id = S.department_id
GROUP BY D.department_name;

-- 🔹 Q3
SELECT C.course_name, AVG(E.grade) AS avg_grade
FROM Courses C
JOIN Enrollments E ON C.course_id = E.course_id
GROUP BY C.course_name
HAVING AVG(E.grade) > 8.0;

-- 🔹 Q4
SELECT P.name, COUNT(CA.course_id) AS courses_taught
FROM Professors P
LEFT JOIN CourseAssignments CA ON P.professor_id = CA.professor_id
GROUP BY P.name;

-- 🔹 Q5
SELECT S.name
FROM Students S
WHERE NOT EXISTS (
    SELECT 1 FROM Enrollments E
    WHERE E.student_id = S.student_id
    AND E.grade <= (
        SELECT AVG(E2.grade)
        FROM Enrollments E2
        WHERE E2.course_id = E.course_id
    )
);

-- 🔹 Q6
SELECT S.name
FROM Students S
WHERE NOT EXISTS (
    SELECT C.course_id
    FROM Courses C
    WHERE C.department_id = S.department_id
    AND C.course_id NOT IN (
        SELECT E.course_id
        FROM Enrollments E
        WHERE E.student_id = S.student_id
    )
);

-- 🔹 Q7
SELECT course_name
FROM Courses
WHERE course_id NOT IN (SELECT DISTINCT course_id FROM Enrollments);

-- 🔹 Q8
SELECT D.department_name
FROM Departments D
WHERE D.department_id NOT IN (SELECT DISTINCT department_id FROM Students)
AND D.department_id IN (SELECT DISTINCT department_id FROM Courses);

-- 🔹 Q9
SELECT C.course_name, S.name, E.grade,
RANK() OVER (PARTITION BY C.course_id ORDER BY E.grade DESC) AS rank
FROM Enrollments E
JOIN Students S ON E.student_id = S.student_id
JOIN Courses C ON E.course_id = C.course_id;

-- 🔹 Q10
SELECT S.name,
MAX(E.grade) AS highest,
MIN(E.grade) AS lowest,
AVG(E.grade) AS average
FROM Students S
JOIN Enrollments E ON S.student_id = E.student_id
GROUP BY S.name;

-- 🔹 Q11 (CTE)
WITH AvgGrades AS (
    SELECT S.student_id, S.name, S.department_id, AVG(E.grade) AS avg_grade
    FROM Students S
    JOIN Enrollments E ON S.student_id = E.student_id
    GROUP BY S.student_id
)
SELECT *
FROM (
    SELECT *, RANK() OVER (PARTITION BY department_id ORDER BY avg_grade DESC) rnk
    FROM AvgGrades
) t
WHERE rnk <= 3;

-- 🔹 Q13 (View)
CREATE VIEW StudentCoursePerformance AS
SELECT S.name, C.course_name, E.grade, D.department_name
FROM Students S
JOIN Enrollments E ON S.student_id = E.student_id
JOIN Courses C ON E.course_id = C.course_id
JOIN Departments D ON S.department_id = D.department_id;

-- 🔹 Q14 (Index)
CREATE INDEX idx_enrollments ON Enrollments(student_id, course_id);

-- 🔹 Q15 (Transaction)
START TRANSACTION;

UPDATE Students
SET department_id = 2
WHERE student_id = 1;

-- If error:
-- ROLLBACK;

-- If success:
COMMIT;

-- 🔹 Q16
SELECT *
FROM Enrollments
WHERE grade < 0 OR grade > 10;

-- 🔹 Q20
SELECT name, avg_grade
FROM (
    SELECT S.name, AVG(E.grade) AS avg_grade,
    NTILE(10) OVER (ORDER BY AVG(E.grade) DESC) AS percentile
    FROM Students S
    JOIN Enrollments E ON S.student_id = E.student_id
    GROUP BY S.name
) t
WHERE percentile = 1;