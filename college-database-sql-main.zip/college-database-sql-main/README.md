# SQL Database Project

This project contains SQL tasks including:

## Basic Queries
- Select, Where, Count

## Intermediate Queries
- Order By, Group By, Aggregations

## Advanced DBMS
- Joins
- Subqueries
- Window Functions
- CTEs
- Views & Indexing
- Transactions

## Tools Used
- MySQL (XAMPP)
- phpMyAdmin
- VS Code
