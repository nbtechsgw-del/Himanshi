document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  var name    = document.getElementById('name').value.trim();
  var email   = document.getElementById('email').value.trim();
  var message = document.getElementById('message').value.trim();
  var msgBox  = document.getElementById('formMsg');
  if (!name || !email || !message) {
    msgBox.textContent = 'Please fill out all fields!';
    msgBox.className = 'error';
    return;
  }
  msgBox.textContent = 'Thank you, ' + name + '! Your message has been sent.';
  msgBox.className = 'success';
  this.reset();
  setTimeout(function() {
    msgBox.textContent = '';
    msgBox.className = '';
  }, 5000);
});
