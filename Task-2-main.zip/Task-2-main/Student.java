public class Student {
    String name;
    int id;
    double marks;
    public Student(String name, int id, double marks) {
        this.name  = name;
        this.id    = id;
        this.marks = marks;
    }
    public void display() {
        System.out.println("ID: " + id + " | Name: " + name + " | Marks: " + marks);
    }
}