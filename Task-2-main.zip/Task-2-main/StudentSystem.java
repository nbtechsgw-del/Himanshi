import java.util.ArrayList;
import java.util.Scanner;
public class StudentSystem {
    ArrayList<Student> studentList = new ArrayList<>();
    public void addStudent(String name, int id, double marks) {
        Student s = new Student(name, id, marks);  
        studentList.add(s);                         
        System.out.println("Student added successfully!");
    }
    public void displayAll() {
        if (studentList.size() == 0) {
            System.out.println("No students found.");
            return;
        }
        System.out.println("\n--- All Students ---");
        for (Student s : studentList) {
            s.display();   
        }
    }
    public void searchById(int id) {
        boolean found = false;
        for (Student s : studentList) {
            if (s.id == id) {
                System.out.println("\nStudent Found");
                s.display();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("No student found with ID: " + id);
        }
    }
     public void calculateAverage() {
        if (studentList.size() == 0) {
            System.out.println("No students to calculate average.");
            return;
        }
        double total = 0;
        for (Student s : studentList) {
            total = total + s.marks;
        }
        double average = total / studentList.size();
        System.out.println("\nTotal Students : " + studentList.size());
        System.out.println("Average Marks  : " + average);
    }
     public static void main(String[] args) {

        StudentSystem system = new StudentSystem();  
        Scanner sc = new Scanner(System.in);
        int choice;
       System.out.println("   Student Management System");
       do {
            System.out.println("\n1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Calculate Average Marks");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Name   : ");
                    String name = sc.next();
                    System.out.print("Enter ID     : ");
                    int id = sc.nextInt();
                    System.out.print("Enter Marks  : ");
                    double marks = sc.nextDouble();
                    system.addStudent(name, id, marks);
                    break;

                case 2:
                    system.displayAll();
                    break;

                case 3:
                    System.out.print("Enter ID to search: ");
                    int searchId = sc.nextInt();
                    system.searchById(searchId);
                    break;

                case 4:
                    system.calculateAverage();
                    break;

                case 5:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 5); 

        sc.close();
    }
}