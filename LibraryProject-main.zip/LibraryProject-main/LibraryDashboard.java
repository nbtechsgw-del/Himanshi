import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.util.ArrayList;

class Book {
    String title, author;
    boolean isIssued;
    LocalDate dueDate;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isIssued = false;
        this.dueDate = null;
    }

    void issueBook() {
        if (!isIssued) {
            isIssued = true;
            dueDate = LocalDate.now().plusDays(7);
        }
    }

    void returnBook() {
        isIssued = false;
        dueDate = null;
    }
}

class Library {
    ArrayList<Book> books = new ArrayList<>();

    void addBook(String title, String author) {
        books.add(new Book(title, author));
    }

    void issueBook(String title) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(title) && !b.isIssued) {
                b.issueBook();
                break;
            }
        }
    }

    void returnBook(String title) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(title) && b.isIssued) {
                b.returnBook();
                break;
            }
        }
    }
}

public class LibraryDashboard {
    static Library library = new Library();
    static DefaultTableModel model;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Library Dashboard");
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Top Title
        JLabel title = new JLabel("Library Management System", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(title, BorderLayout.NORTH);

        // Table
        String[] columns = {"Title", "Author", "Status", "Due Date"};
        model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        frame.add(new JScrollPane(table), BorderLayout.CENTER);

        // Input Panel
        JPanel panel = new JPanel();
        JTextField titleField = new JTextField(10);
        JTextField authorField = new JTextField(10);

        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Author:"));
        panel.add(authorField);

        JButton addBtn = new JButton("Add");
        JButton issueBtn = new JButton("Issue");
        JButton returnBtn = new JButton("Return");

        panel.add(addBtn);
        panel.add(issueBtn);
        panel.add(returnBtn);

        frame.add(panel, BorderLayout.SOUTH);

        // Button Actions
        addBtn.addActionListener(e -> {
            library.addBook(titleField.getText(), authorField.getText());
            refreshTable();
        });

        issueBtn.addActionListener(e -> {
            library.issueBook(titleField.getText());
            refreshTable();
        });

        returnBtn.addActionListener(e -> {
            library.returnBook(titleField.getText());
            refreshTable();
        });

        frame.setVisible(true);
    }

    static void refreshTable() {
        model.setRowCount(0);
        for (Book b : library.books) {
            String status = b.isIssued ? "Issued" : "Available";
            String due = (b.dueDate != null) ? b.dueDate.toString() : "-";
            model.addRow(new Object[]{b.title, b.author, status, due});
        }
    }
}